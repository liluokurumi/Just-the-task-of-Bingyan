using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace netcore
{
    class HashTable<T>
    {
        private List<T> KeyList;
        private List<T> ValueList;
        public HashTable()
        {
            KeyList = new List<T>();
            ValueList = new List<T>();
        }
        public void Add(T key,T Value)
        {
            KeyList.Add(key);
            ValueList.Add(Value);

        }
        public void RemoveKey(T key)
        {
            int num1 = KeyList.IndexOf(key);
            KeyList.RemoveAt(num1);
            ValueList.RemoveAt(num1);
        }
        public T ValueFind(T key)
        {
            int num = KeyList.IndexOf(key);
            T ValueItem = ValueList[num];
            return ValueItem;
        }
        public T KeyFind(T Value)
        {
            int num = ValueList.IndexOf(Value);
            T KeyItem = KeyList[num];
            return KeyItem;
        }
        public void Clear()
        {
            KeyList.Clear();
            ValueList.Clear();
        }
        public List<T> AllKey()
        {
            return KeyList;
        }
        public List<T> AllValue()
        {
            return ValueList;
        }
    }
}