using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace netcore
{
    class BinaryTree<T>
    {
        public T[] Tree;
        public int n {get;set;}
        public BinaryTree(int size,T root)
        {
            Tree = new T[size+1];
            n = size;
            Tree[0] = default(T);
            Tree[1] = root;
            for(int i = 2;i <= n;i++)
            {
                Tree[i] = default(T);
            }
        }
        public void Rewrite(int num,T content)
        {
            if(num <= n&&num>=1)
            {
                if(Tree[num/2].Equals(default(T)))
                {
                    Console.WriteLine("父节点为空!");
                }
                else
                Tree[num] = content;
            }
            else
            Console.WriteLine("您输入的坐标不在树范围内");
        }
        public void Rewrite(int layer,int index,T content)
        {
            double num1 = System.Math.Pow(2.0,layer-1)-1+index;
            int num = (int)num1;
            if(num <= n&&num>=1)
            {
                if(Tree[num/2].Equals(default(T)))
                {
                    Console.WriteLine("父节点为空!");
                }
                else
                Tree[num] = content;
            }
            else
            Console.WriteLine("您输入的坐标不在树范围内");
        }
        public int TreeDepth()
        {
            int j =-1;
            int i = n;
            for(int num2 = i;num2>=1;num2--)
            {
                if(!Tree[num2].Equals(default(T)))
                {
                    i = num2;
                    break;
                }
            }
            do
              j++;
            while (i>=System.Math.Pow(2,j));
            return j;
        }
        public T Value(int num)
        {
            return Tree[num];
        }
        public T Value(int layer,int index)
        {
            double num1 = System.Math.Pow(2.0,layer-1)-1+index;
            int num = (int)num1;
            return Tree[num];
        }
        public int GetIndexOf(T content)
        {
            for(int i=1;i<=n;i++)
            {
                if(Tree[i].Equals(content))
                return i;
            }
            Console.WriteLine("未找到该节点");
            return -1;
        }
        public T LeftChild(T content)
        {
            int num = GetIndexOf(content);
            if (num*2<=n&&!(Tree[num*2].Equals(default(T))))
            return Tree[num*2];
            else
            {
                Console.WriteLine("没有左子节点或左子节点超出范围");
                return default(T);
            }
        }
        public T RightChild(T content)
        {
            int num = GetIndexOf(content);
            if ((num*2+1)<=n&&!(Tree[num*2+1].Equals(default(T))))
            return Tree[num*2+1];
            else
            {
                Console.WriteLine("没有左子节点或左子节点超出范围");
                return default(T);
            }
        }
        public T Parent(T content)
        {
            int num = GetIndexOf(content);
            return Tree[num/2];
        }
        public void Move(int i,int j)
        {
            if((!Tree[i].Equals(default(T))&&(!Tree[j].Equals(default(T)))))
            {
                for(int x = 2;x*i<=n&&j*x<=n;x*=2)
                {
                    for(int y = 0;y<x&&(x*i+y)<=n&&(x*j+y)<=n;y++)
                    {
                        T temp = Tree[x*i+y];
                        Tree[x*i+y] = Tree[x*j+y];
                        Tree[x*j+y] = temp;
                        if((x*i+y)==n||(x*j+y)==n)
                        Console.WriteLine("到达上限,无法完整交换");
                    }
                }
            }
            else
            Console.WriteLine("有一个节点不存在");
        }
        public void Remove(int index)
        {
            for(int x = 2;x*index<=n;x*=2)
            {
                for(int y = 0;y<x&&(x*index+y)<=n;y++)
                {
                    Tree[x*index+y] = default(T);
                }
            }
        }
        public void InsertChild(int index,BinaryTree<T> tree)
        {
            if(Tree[index*2].Equals(default(T)))
            {
                Tree[index*2] = tree.Tree[1];
                int count = 2;
                for(int x = 2;x*index*2<=n;x*=2)
                {
                    for(int y = 0;y<x&&(x*index*2+y)<=n;y++,count++)
                    {
                        Tree[x*index*2+y] = tree.Tree[count];
                    }
                    if(count == tree.n)
                    break;
                }
            }
        }
        public void PrintTree()
        {
            int num = 1;
            for(int x = 2;x*num<=n;x*=2)
                {
                    for(int y = 0;y<x&&(x*num+y)<=n;y++)
                    {
                        Console.WriteLine(Tree[x*num+y]);
                    }
                }
        }
        public void PrintTree(int index)
        {
            int num = index;
            for(int x = 2;x*num<=n;x*=2)
                {
                    for(int y = 0;y<x&&(x*num+y)<=n;y++)
                    {
                        Console.WriteLine(Tree[x*num+y]);
                    }
                }
        }
    }
}