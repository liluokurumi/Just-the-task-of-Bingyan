using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace netcore
{
    class Heap<T> where T :IComparable
    {
        public T[] data;
        public int n {get;set;}
        public int count {get;set;}
        public Heap(int size,T root,T RootLeftChild,T RootRightChild)
        {
            n = size;
            data = new T[size+1];
            data[0] = default(T);
            data[1] = root;
            data[2] = RootLeftChild;
            data[3] = RootRightChild;
            count = 3;
            this.HeadSort();
        }
        void Swap(int x,int y)
        {
            T temp = data[x];
            data[x] = data[y];
            data[y] = temp;
        }
        public void HeadAdjust(int from,int to)
        {
            int j;
            T temp = data[from];
            for(j=2*from;j<=to;j*=2)
            {
                if(j<to&&(data[j].CompareTo(data[j+1])<0))
                    ++j;
                if(temp.CompareTo(data[j])>=0)
                    break;
                data[from] = data[j];
                from = j;    
            }
            data[from] = temp;
        }
        public void HeadSort()
        {
            for(int i = count/2;i>0;i--)
            HeadAdjust(i,count);
        }
        public void Push(T content)
        {
            count+=1;
            data[count] = content;
            this.HeadSort();
        }
        public T Top()
        {
            return data[1];
        }
        public T Pop()
        {
            this.Swap(1,count);
            T temp = data[count];
            count-=1;
            this.HeadSort();
            return temp;
        }
    }
}