﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//模拟队列,列表,栈,链表
namespace netcore
{
    class Program
    {
        static void Main()
        {
            //队列
            // SeQueue<int> queue1 = new SeQueue<int>(100);
            // queue1.EnQueue(1);
            // for (int item = 3;item <= 102;item++)
            // {
            //     queue1.EnQueue(item);
            // }
            // for (int n = 3;n <= 102;n++)
            // {
            //     Console.WriteLine(queue1.DeQueue());
            // }
            //列表
            // SimulatedList<int> list1 = new SimulatedList<int>();
            // list1.CreatList(10);
            // for(int i = 0;i<=20;i++)
            // {
            //     list1.AddList(i-100);
            //     Console.WriteLine(list1[i]);

            // }
            // Console.WriteLine(list1.GetIndexOf(-95));
            // list1.Insert(14,332501);
            // for (int i = 14;i<=20;i++)
            // {
            //     Console.WriteLine(list1[i]);
            // }
            // list1.Remove(14);
            // for (int i = 14;i<=20;i++)
            // {
            //     Console.WriteLine(list1[i]);
            // }
            //栈
            // SimulatedStack<int> Stack1 = new SimulatedStack<int>();
            // Stack1.SeStack(10);
            // for(int i=0;i<=30;i++)
            // {
            //     Stack1.Push(i-100);
            //     Console.WriteLine(Stack1.Peek());
            // }
            // for(int i = 0;i<=15;i++)
            // {
            //     Console.WriteLine(Stack1.Pop());
            // }
            // 链表
            // LinkedListItem<int> a = new LinkedListItem<int>(4464);
            // LinkedList<int> linkedList1 = new LinkedList<int>(a,2626);
            // LinkedListItem<int> b = new LinkedListItem<int>(8848);
            // linkedList1.Add(b);
            // LinkedListItem<int> c = new LinkedListItem<int>(44648848);
            // linkedList1.Insert(a,c);
            // Console.WriteLine(a.Next.Content);
            // linkedList1.Remove(c);
            // Console.WriteLine(a.Next.Content);
            // LinkedListItem<int> d = new LinkedListItem<int>(8848123);
            // linkedList1.Add(d);
            // Console.WriteLine(b.Next.Content);
            // LinkedListItem<int> e = linkedList1.Find(4464);
            // Console.WriteLine(e.Next.Content);
            // LinkedListItem<int> f = new LinkedListItem<int>(9999);
            // linkedList1.AddToFirst(f);
            // Console.WriteLine(f.Next.Content);
            // foreach (int i in linkedList1)
            // {
            //     Console.WriteLine(i);
            // }
            //哈希表
            // HashTable<int> table1 = new HashTable<int>();
            // table1.Add(1,123456);
            // table1.Add(3,987456);
            // Console.WriteLine(table1.KeyFind(123456));
            // table1.Add(9,956);
            // table1.Add(7,9856);
            // table1.RemoveKey(9);
            // Console.WriteLine(table1.ValueFind(7));
            //二叉树
            // BinaryTree<int> Tree1 = new BinaryTree<int>(100,10086);
            // for(int n = 2;n<=100;n++)
            // {
            //     Tree1.Rewrite(n,10085+n);
            // }
            // Console.WriteLine(Tree1.TreeDepth());
            // Console.WriteLine(Tree1.GetIndexOf(10093));
            // Console.WriteLine(Tree1.Value(5,1));
            // Console.WriteLine(Tree1.LeftChild(10089));
            // Console.WriteLine(Tree1.Parent(10093));
            // Tree1.PrintTree();
            // Tree1.PrintTree(2);
            // Console.WriteLine(Tree1.Value(16));
            // Console.WriteLine("-----------------------");
            // Tree1.Move(Tree1.GetIndexOf(10093),Tree1.GetIndexOf(10096));
            // Console.WriteLine("-----------------------");
            // Console.WriteLine(Tree1.Value(16));
            // Console.WriteLine("-----------------------");
            // Tree1.PrintTree(2);
            // Console.WriteLine("-----------------------");
            // Tree1.Remove(Tree1.GetIndexOf(10093));
            // Tree1.PrintTree(2);
            // BinaryTree<int> Tree2 = new BinaryTree<int>(7,110);
            // for(int n = 2;n<=7;n++)
            // {
            //     Tree2.Rewrite(n,109+n);
            // }
            // Tree1.InsertChild(Tree1.GetIndexOf(10093),Tree2);
            // Tree1.PrintTree(2);
            // 堆
            // Heap<int> Heap1 = new Heap<int>(50,106,123,666);
            // Random ran =new Random();
            // for(int i = 4;i<=30;i++)
            // {
            //     int RandKey=ran.Next(100,999);
            //     Heap1.Push(RandKey);
            // }
            // for(int j = 4;j<=30;j++)
            // {
            //     Console.WriteLine(Heap1.Pop());
            // }
        }
    }
}
