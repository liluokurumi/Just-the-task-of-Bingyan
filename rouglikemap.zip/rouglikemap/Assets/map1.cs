using System.Collections;
using System.Collections.Generic;
using UnityEditor.Build;
using UnityEngine;

public class map1 : MonoBehaviour
{
    public int x, y,TryNum,DeleteAisle;
    int Delete = 0;
    Dictionary<Vector3, CubeType> map;
    Dictionary<Vector3, GameObject> link;
    List<GameObject> RoomLink;
    int dx = 1;
    int dy = 0;
    // Start is called before the first frame update
    void Start()
    {
        GameObject asile = GameObject.Find("aisle").gameObject;
        GameObject asileside = GameObject.Find("aisleside").gameObject;
        int roomnum;
        roomnum = 1;
        GameObject mapside = GameObject.Find("mapside").gameObject;
        GameObject stone = GameObject.Find("stone").gameObject;
        GameObject room = GameObject.Find("room").gameObject;
        GameObject roomx = default;
        map = new Dictionary<Vector3, CubeType>();
        link = new Dictionary<Vector3, GameObject>();
        RoomLink = new List<GameObject>();
        for (int i = 0; i <= (x + 1); i++)
        {
            Vector3 ItemPosition = new Vector3(i, 0, 0);
            CubeType MapSide = new CubeType(ItemPosition, 3);
            map.Add(ItemPosition, MapSide);
            MapSide.Cube = Instantiate(MapSide.PrefabCube, MapSide.Position, default, mapside.transform);
        }
        for (int i = 0; i <= (x + 1); i++)
        {
            Vector3 ItemPosition = new Vector3(i, y+1, 0);
            CubeType MapSide = new CubeType(ItemPosition, 3);
            map.Add(ItemPosition, MapSide);
            MapSide.Cube = Instantiate(MapSide.PrefabCube, MapSide.Position, default, mapside.transform);
        }
        for (int i = 1; i <= y; i++)
        {
            Vector3 ItemPosition = new Vector3(0, i, 0);
            CubeType MapSide = new CubeType(ItemPosition, 3);
            map.Add(ItemPosition, MapSide);
            MapSide.Cube = Instantiate(MapSide.PrefabCube, MapSide.Position, default, mapside.transform);
        }
        for (int i = 1; i <= y; i++)
        {
            Vector3 ItemPosition = new Vector3(x+1, i, 0);
            CubeType MapSide = new CubeType(ItemPosition, 3);
            map.Add(ItemPosition, MapSide);
            MapSide.Cube = Instantiate(MapSide.PrefabCube, MapSide.Position, default, mapside.transform);
        }
        for (int j = 1; j <= y; j++)
        {
            for (int i = 1; i <= x; i++)
            {
                Vector3 ItemPosition = new Vector3(i, j, 0);
                CubeType Stone = new CubeType(ItemPosition, 4);
                map.Add(ItemPosition, Stone);
                Stone.Cube = Instantiate(Stone.PrefabCube, Stone.Position, default, stone.transform);
            }
        }
        for (int i = 1; i <= TryNum; i++)
        {
            int sizex = Random.Range(4, 10);
            int sizey = Random.Range(4, 10);
            bool judge = true;
            Vector3 RandomPosition = new Vector3(Random.Range(1, x), Random.Range(1, y), 0);
            Vector3 TryPosition;
            for (int sy = 1; sy <= sizey; sy++)
            {
                CubeType scan;
                for (int sx = 1; sx <= sizex; sx++)
                {
                    TryPosition = new Vector3((int)RandomPosition.x + sx, (int)RandomPosition.y + sy, 0);
                    map.TryGetValue(TryPosition, out scan);
                    if (scan.Type != 4)
                    {
                        judge = false;
                        break;
                    }
                    if(((int)RandomPosition.y+sizey)>=y|| ((int)RandomPosition.x + sizex) >= x)
                    {
                        judge = false;
                        break;
                    }
                }
                if (!judge)
                    break;
            }
            if(judge)
            {
                CubeType change;
                GameObject RoomItem = new GameObject("room" + roomnum);
                RoomItem.transform.parent = room.transform;
                for (int hx = (int)RandomPosition.x+1; hx <= (int)RandomPosition.x+sizex; hx++)
                {
                    Vector3 ItemPosition = new Vector3(hx, (int)RandomPosition.y, 0);
                    map.TryGetValue(ItemPosition, out change);
                    change.ChangeType(3);
                    change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                }
                for (int hx = (int)RandomPosition.x+1; hx <= (int)RandomPosition.x + sizex; hx++)
                {
                    Vector3 ItemPosition = new Vector3(hx, (int)RandomPosition.y+sizey+1, 0);
                    map.TryGetValue(ItemPosition, out change);
                    change.ChangeType(3);
                    change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                }
                for (int hy = (int)RandomPosition.y+1; hy <= (int)RandomPosition.y + sizey; hy++)
                {
                    Vector3 ItemPosition = new Vector3((int)RandomPosition.x, hy, 0);
                    map.TryGetValue(ItemPosition, out change);
                    change.ChangeType(3);
                    change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                }
                for (int hy = (int)RandomPosition.y+1; hy <= (int)RandomPosition.y + sizey; hy++)
                {
                    Vector3 ItemPosition = new Vector3((int)RandomPosition.x+sizex+1, hy, 0);
                    map.TryGetValue(ItemPosition, out change);
                    change.ChangeType(3);
                    change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                }
                Vector3 SidePosition1 = new Vector3((int)RandomPosition.x, (int)RandomPosition.y, 0);
                map.TryGetValue(SidePosition1, out change);
                change.ChangeType(3);
                change.SType = 6;
                change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                Vector3 SidePosition2 = new Vector3((int)RandomPosition.x+sizex+1, (int)RandomPosition.y, 0);
                map.TryGetValue(SidePosition2, out change);
                change.ChangeType(3);
                change.SType = 6;
                change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                Vector3 SidePosition3 = new Vector3((int)RandomPosition.x, (int)RandomPosition.y+sizey+1, 0);
                map.TryGetValue(SidePosition3, out change);
                change.ChangeType(3);
                change.SType = 6;
                change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                Vector3 SidePosition4 = new Vector3((int)RandomPosition.x+sizex+1, (int)RandomPosition.y+sizey+1, 0);
                map.TryGetValue(SidePosition4, out change);
                change.ChangeType(3);
                change.SType = 6;
                change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                for (int ry = 1; ry <= sizey; ry++)
                {
                    for(int rx=1;rx<=sizex;rx++)
                    {
                        Vector3 ItemPosition = new Vector3((int)RandomPosition.x + rx, (int)RandomPosition.y + ry, 0);
                        map.TryGetValue(ItemPosition, out change);
                        change.ChangeType(1);
                        change.Cube = Instantiate(change.PrefabCube, change.Position, default, RoomItem.transform);
                    }
                }
            }
            roomnum += 1;
        }
        int TypeNum = 0;
        CubeType Asile;
        for(int j = 2;j<=y;j++)
        {
            for(int i = 2;i<=x;i++)
            {
                Vector3 AsilePosition = new Vector3(i, j, 0);
                map.TryGetValue(AsilePosition, out Asile);
                TypeNum = Asile.SType;
                if(TypeNum==4)
                {
                    Asile.ChangeType(2);
                    Asile.Cube = Instantiate(Asile.PrefabCube, Asile.Position, default, asile.transform);
                    FloodFill(AsilePosition);
                }
            }
        }
        foreach(Transform child in room.transform)
        {
            roomx = child.gameObject;
            LinkRoom(roomx);
            LinkRoom(roomx);
        }
        //RoomGrow();
        Debug.Log(asile.transform.childCount);
        foreach(Transform child in asile.transform)
        {
            ClearAsile(child.position,1);
        }
        Debug.Log(asile.transform.childCount);
    }
    // Update is called once per frame
    void Update()
    {
        
    }
    void FloodFill(Vector3 Position)
    {
        GameObject stone = GameObject.Find("stone").gameObject;
        GameObject asile = GameObject.Find("aisle").gameObject;
        GameObject asileside = GameObject.Find("aisleside").gameObject;
        //���ǵ÷����ݹ�!!!
        CubeType side1, side2,NewAsile;
        Vector3 NewPosition = new Vector3((int)Position.x + dx, (int)Position.y + dy, 0);
        int FrontType = GetType(NewPosition);
        bool judge = true;
        CubeType a, b, c;
        if(dx==0)
        {
            Vector3 Positionl = new Vector3((int)Position.x - 1, (int)Position.y, 0);
            Vector3 Positionr = new Vector3((int)Position.x + 1, (int)Position.y, 0);
            Vector3 Positionf = new Vector3((int)Position.x, (int)Position.y + dy, 0);
            if((Positionl.x<=x+1)&&(Positionl.x>=0)&&(Positionl.y<=y+1)&&(Positionl.y>=0)
                &&(Positionr.x <= x + 1) && (Positionr.x >= 0) && (Positionr.y <= y + 1) && (Positionr.y >= 0)
                && (Positionf.x <= x + 1) && (Positionf.x >= 0) && (Positionf.y <= y + 1) && (Positionf.y >= 0))
            { 
                map.TryGetValue(Positionl, out a);
                map.TryGetValue(Positionr, out b);
                map.TryGetValue(Positionf, out c);
                if ((c.SType != 4) && !((b.SType == 4) && (a.SType == 4)))
                {
                    if ((a.SType != 4) && (b.SType != 4))
                    {
                        judge = false;
                    }
                    else
                    {
                        if ((a.SType == 4) && (b.SType != 4))
                        {
                            dx = -1;
                            dy = 0;
                            NewPosition = Positionl;
                        }
                        else if ((a.SType != 4) && (b.SType == 4))
                        {
                            dx = 1;
                            dy = 0;
                            NewPosition = Positionr;
                        }
                        if ((((int)NewPosition.y + 1) <= y) && (((int)NewPosition.y - 1) >= 0))
                        {
                            map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y + 1, 0), out side1);
                            map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y - 1, 0), out side2);
                            if (side1.SType == 4)
                            {
                                side1.ChangeType(3);
                                side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                                side1.SType = 5;
                            }
                            if (side2.SType == 4)
                            {
                                side2.ChangeType(3);
                                side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                                side2.SType = 5;
                            }
                        }
                        map.TryGetValue(NewPosition, out NewAsile);
                        NewAsile.ChangeType(2);
                        NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                        FloodFill(NewPosition);
                        judge = false;
                    }
                }
            }
        }
        else if (dy == 0)
        {
            Vector3 Positionl = new Vector3((int)Position.x, (int)Position.y - 1, 0);
            Vector3 Positionr = new Vector3((int)Position.x, (int)Position.y + 1, 0);
            Vector3 Positionf = new Vector3((int)Position.x + dx, (int)Position.y, 0);
            if ((Positionl.x <= x + 1) && (Positionl.x >= 0) && (Positionl.y <= y + 1) && (Positionl.y >= 0)
                && (Positionr.x <= x + 1) && (Positionr.x >= 0) && (Positionr.y <= y + 1) && (Positionr.y >= 0)
                && (Positionf.x <= x + 1) && (Positionf.x >= 0) && (Positionf.y <= y + 1) && (Positionf.y >= 0))
            {
                map.TryGetValue(Positionl, out a);
                map.TryGetValue(Positionr, out b);
                map.TryGetValue(Positionf, out c);
                if ((c.SType != 4) && !((b.SType == 4) && (a.SType == 4)))
                {
                    if ((a.SType != 4) && (b.SType != 4))
                    {
                        judge = false;
                    }
                    else
                    {
                        if ((a.SType == 4) && (b.SType != 4))
                        {
                            dx = 0;
                            dy = -1;
                            NewPosition = Positionl;
                        }
                        else if ((a.SType != 4) && (b.SType == 4))
                        {
                            dx = 0;
                            dy = -1;
                            NewPosition = Positionr;
                        }
                        if ((((int)NewPosition.y + 1) <= y) && (((int)NewPosition.y - 1) >= 0))
                        {
                            map.TryGetValue(new Vector3((int)NewPosition.x + 1, (int)NewPosition.y, 0), out side1);
                            map.TryGetValue(new Vector3((int)NewPosition.x - 1, (int)NewPosition.y, 0), out side2);
                            if (side1.SType == 4)
                            {
                                side1.ChangeType(3);
                                side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                                side1.SType = 5;
                            }
                            if (side2.SType == 4)
                            {
                                side2.ChangeType(3);
                                side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                                side2.SType = 5;
                            }
                        }
                        map.TryGetValue(NewPosition, out NewAsile);
                        NewAsile.ChangeType(2);
                        NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                        FloodFill(NewPosition);
                        judge = false;
                    }
                }
            }
        }
        if (judge)
        { if (FrontType == 4)
            {
                CubeType MoveCube;
                Vector3 MovePosition;
                MovePosition = NewPosition;
                bool workx,worky;
                workx = false;
                worky = false;
                int ddx, ddy;
                ddx = dx;
                ddy = dy;
                map.TryGetValue(NewPosition, out NewAsile);
                NewAsile.ChangeType(2);
                NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                int rate1 = Random.Range(2, 5);
                int rate2 = Random.Range(0, 2);
                if(true)
                {
                    CubeType TryCube;
                    Vector3 temp = new Vector3((int)NewPosition.x - dx, (int)NewPosition.y - dy, 0);
                    if(dx==0)
                    {
                        ddy = 0;
                        if (rate2 == 0)
                            ddx = 1;
                        else
                            ddx = -1;
                        Vector3 TryPosition = new Vector3((int)temp.x + ddx, (int)temp.y + ddy, 0);
                        map.TryGetValue(TryPosition, out TryCube);
                        if(TryCube.SType==4)
                        {
                            MovePosition = TryPosition;
                            workx = true;
                        }
                        else
                        {
                            ddx = -ddx;
                            TryPosition = new Vector3((int)temp.x + ddx, (int)temp.y + ddy, 0);
                        }
                        if (TryCube.SType == 4)
                        {
                            MovePosition = TryPosition;
                            workx = true;
                        }
                    }
                    if (dy == 0)
                    {
                        ddx = 0;
                        if (rate2 == 0)
                            ddy = 1;
                        else
                            ddy = -1;
                        Vector3 TryPosition = new Vector3((int)temp.x + ddx, (int)temp.y + ddy, 0);
                        map.TryGetValue(TryPosition, out TryCube);
                        if (TryCube.SType == 4)
                        {
                            MovePosition = TryPosition;
                            worky = true;
                        }
                        else
                        {
                            ddy = -ddy;
                            TryPosition = new Vector3((int)temp.x + ddx, (int)temp.y + ddy, 0);
                        }
                        if (TryCube.SType == 4)
                        {
                            MovePosition = TryPosition;
                            worky = true;
                        }
                    }
                }
                if (dy == 0)
                {
                    if ((((int)NewPosition.y + 1) <= y) && (((int)NewPosition.y - 1) >= 0))
                    {
                        map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y + 1, 0), out side1);
                        map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y - 1, 0), out side2);
                        if (side1.SType == 4)
                        {
                            side1.ChangeType(3);
                            side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                            side1.SType = 5;
                        }
                        if (side2.SType == 4)
                        {
                            side2.ChangeType(3);
                            side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                            side2.SType = 5;
                        }
                    }
                    if (worky)
                    {
                        dx = ddx;
                        dy = ddy;
                        map.TryGetValue(MovePosition, out MoveCube);
                        MoveCube.ChangeType(4);
                        MoveCube.Cube = Instantiate(MoveCube.PrefabCube, MoveCube.Position, default, stone.transform);
                        MoveCube.SType = 4;
                    }
                }
                if (dx == 0)
                {
                    if ((((int)NewPosition.x + 1) <= y) && (((int)NewPosition.x - 1) >= 0))
                    {
                        map.TryGetValue(new Vector3((int)NewPosition.x + 1, (int)NewPosition.y, 0), out side1);
                        map.TryGetValue(new Vector3((int)NewPosition.x - 1, (int)NewPosition.y, 0), out side2);
                        if (side1.SType == 4)
                        {
                            side1.ChangeType(3);
                            side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                            side1.SType = 5;
                        }
                        if (side2.SType == 4)
                        {
                            side2.ChangeType(3);
                            side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                            side2.SType = 5;
                        }
                        if(workx)
                        {
                            dx = ddx;
                            dy = ddy;
                            map.TryGetValue(MovePosition, out MoveCube);
                            MoveCube.ChangeType(4);
                            MoveCube.Cube = Instantiate(MoveCube.PrefabCube, MoveCube.Position, default, stone.transform);
                            MoveCube.SType = 4;
                        }
                    }
                }
                FloodFill(NewPosition);
            }
            else if (FrontType == 5)
            {
                int choose = Random.Range(0, 2);
                if (dx == 0)
                {
                    if (choose == 0)
                    {
                        NewPosition = new Vector3((int)NewPosition.x - 1, (int)NewPosition.y - dy, 0);
                        dx = -1;
                        dy = 0;
                    }
                    else if (choose == 1)
                    {
                        NewPosition = new Vector3((int)NewPosition.x + 1, (int)NewPosition.y - dy, 0);
                        dx = 1;
                        dy = 0;
                    }
                    if ((((int)NewPosition.y + 1) <= y) && (((int)NewPosition.y - 1) >= 0))
                    {
                        map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y + 1, 0), out side1);
                        map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y - 1, 0), out side2);
                        if (side1.SType == 4)
                        {
                            side1.ChangeType(3);
                            side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                            side1.SType = 5;
                        }
                        if (side2.SType == 4)
                        {
                            side2.ChangeType(3);
                            side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                            side2.SType = 5;
                        }
                    }
                }
                else if (dy == 0)
                {
                    if (choose == 0)
                    {
                        NewPosition = new Vector3((int)NewPosition.x - dx, (int)NewPosition.y - 1, 0);
                        dx = 0;
                        dy = -1;
                    }
                    else if (choose == 1)
                    {
                        NewPosition = new Vector3((int)NewPosition.x - dx, (int)NewPosition.y + 1, 0);
                        dx = 0;
                        dy = 1;
                    }
                    if ((((int)NewPosition.x + 1) <= y) && (((int)NewPosition.x - 1) >= 0))
                    {
                        map.TryGetValue(new Vector3((int)NewPosition.x + 1, (int)NewPosition.y, 0), out side1);
                        map.TryGetValue(new Vector3((int)NewPosition.x - 1, (int)NewPosition.y, 0), out side2);
                        if (side1.SType == 4)
                        {
                            side1.ChangeType(3);
                            side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                            side1.SType = 5;
                        }
                        if (side2.SType == 4)
                        {
                            side2.ChangeType(3);
                            side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                            side2.SType = 5;
                        }
                    }
                }
                map.TryGetValue(NewPosition, out NewAsile);
                NewAsile.ChangeType(2);
                NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                FloodFill(NewPosition);
            }
            else if (FrontType == 3)
            {
                if (dx == 0)
                {
                    Vector3 temp = NewPosition;
                    NewPosition = new Vector3((int)temp.x + 1, (int)temp.y - dy, 0);
                    CubeType test;
                    map.TryGetValue(NewPosition, out test);
                    if (test.SType == 4)
                    {
                        dx = 1;
                        dy = 0;
                        if ((((int)NewPosition.y + 1) <= y) && (((int)NewPosition.y - 1) >= 0))
                        {
                            map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y + 1, 0), out side1);
                            map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y - 1, 0), out side2);
                            if (side1.SType == 4)
                            {
                                side1.ChangeType(3);
                                side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                                side1.SType = 5;
                            }
                            if (side2.SType == 4)
                            {
                                side2.ChangeType(3);
                                side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                                side2.SType = 5;
                            }
                        }
                        map.TryGetValue(NewPosition, out NewAsile);
                        NewAsile.ChangeType(2);
                        NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                        FloodFill(NewPosition);
                    }

                    NewPosition = new Vector3((int)temp.x - 1, (int)temp.y - dy, 0);
                    if (NewPosition.x <= x && NewPosition.y <= y)
                    {
                        map.TryGetValue(NewPosition, out test);
                        if (test.SType == 4)
                        {
                            dx = -1;
                            dy = 0;
                            if ((((int)NewPosition.y + 1) <= y) && (((int)NewPosition.y - 1) >= 0))
                            {
                                map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y + 1, 0), out side1);
                                map.TryGetValue(new Vector3((int)NewPosition.x, (int)NewPosition.y - 1, 0), out side2);
                                if (side1.SType == 4)
                                {
                                    side1.ChangeType(3);
                                    side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                                    side1.SType = 5;
                                }
                                if (side2.SType == 4)
                                {
                                    side2.ChangeType(3);
                                    side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                                    side2.SType = 5;
                                }
                            }
                            map.TryGetValue(NewPosition, out NewAsile);
                            NewAsile.ChangeType(2);
                            NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                            FloodFill(NewPosition);
                        }
                    }
                }
                else if (dy == 0)
                {
                    Vector3 temp = NewPosition;
                    NewPosition = new Vector3((int)temp.x - dx, (int)temp.y + 1, 0);
                    dx = 0;
                    dy = 1;
                    if ((((int)NewPosition.x + 1) <= y) && (((int)NewPosition.x - 1) >= 0))
                    {
                        map.TryGetValue(new Vector3((int)NewPosition.x + 1, (int)NewPosition.y, 0), out side1);
                        map.TryGetValue(new Vector3((int)NewPosition.x - 1, (int)NewPosition.y, 0), out side2);
                        if (side1.SType == 4)
                        {
                            side1.ChangeType(3);
                            side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                            side1.SType = 5;
                        }
                        if (side2.SType == 4)
                        {
                            side2.ChangeType(3);
                            side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                            side2.SType = 5;
                        }
                    }
                    map.TryGetValue(NewPosition, out NewAsile);
                    NewAsile.ChangeType(2);
                    NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                    FloodFill(NewPosition);

                    NewPosition = new Vector3((int)temp.x - dx, (int)temp.y - 1, 0);
                    dx = 0;
                    dy = -1;
                    if ((((int)NewPosition.x + 1) <= y) && (((int)NewPosition.x - 1) >= 0))
                    {
                        map.TryGetValue(new Vector3((int)NewPosition.x + 1, (int)NewPosition.y, 0), out side1);
                        map.TryGetValue(new Vector3((int)NewPosition.x - 1, (int)NewPosition.y, 0), out side2);
                        if (side1.SType == 4)
                        {
                            side1.ChangeType(3);
                            side1.Cube = Instantiate(side1.PrefabCube, side1.Position, default, asileside.transform);
                            side1.SType = 5;
                        }
                        if (side2.SType == 4)
                        {
                            side2.ChangeType(3);
                            side2.Cube = Instantiate(side2.PrefabCube, side2.Position, default, asileside.transform);
                            side2.SType = 5;
                        }
                    }
                    if (NewPosition.x <= x && NewPosition.x >= 1 && NewPosition.y <= y && NewPosition.y >= 0)
                    {
                        map.TryGetValue(NewPosition, out NewAsile);
                        NewAsile.ChangeType(2);
                        NewAsile.Cube = Instantiate(NewAsile.PrefabCube, NewAsile.Position, default, asile.transform);
                        FloodFill(NewPosition);
                    }
                }
            }
        }
    }
    int GetType(Vector3 Position)
    {
        CubeType temp;
        map.TryGetValue(Position, out temp);
        return temp.SType;
    }
    void LinkRoom(GameObject room)
    {
        GameObject RoomSide = default;
        CubeType FindCube;
        Vector3 rp;
        Vector3 write;
        GameObject temp;
        List<GameObject> side = new List<GameObject>();
        foreach (Transform child in room.transform)
        {
            if (child.name == "room(Clone)")
                break;
            Vector3 cp = child.position;
            Vector3 up = new Vector3((int)cp.x, (int)cp.y + 1, 0);
            Vector3 down = new Vector3((int)cp.x, (int)cp.y - 1, 0);
            Vector3 left = new Vector3((int)cp.x - 1, (int)cp.y, 0);
            Vector3 right = new Vector3((int)cp.x + 1, (int)cp.y, 0);
            CubeType CUpCube, CDownCube, CLeftCube, CRightCube;
            map.TryGetValue(up, out CUpCube);
            map.TryGetValue(down, out CDownCube);
            map.TryGetValue(left, out CLeftCube);
            map.TryGetValue(right, out CRightCube);
            if((CUpCube.SType==2|| CDownCube.SType == 2|| CLeftCube.SType == 2|| CRightCube.SType == 2)
                &&(CUpCube.SType == 1 || CDownCube.SType == 1 || CLeftCube.SType == 1 || CRightCube.SType == 1))
            {
                side.Add(child.gameObject);
            }
        }
        int find = Random.Range(0, side.Count - 1);
        RoomSide = side[find];
        foreach(KeyValuePair<Vector3,CubeType> kvp in map)
        {
            rp = kvp.Key;
            map.TryGetValue(rp, out FindCube);
            if(FindCube.Cube.Equals(RoomSide))
            {
                FindCube.ChangeType(2);
                FindCube.Cube = Instantiate(FindCube.PrefabCube, FindCube.Position, default, room.transform);
                FindCube.SType = 7;
                break;
            }
        }
        foreach (Transform child in room.transform)
        {
            write = child.position;
            if(!link.ContainsKey(write))
            link.Add(write, child.gameObject);
            else
            {
                link.TryGetValue(write, out temp);
                temp = child.gameObject;
            }
        }
        RoomLink.Add(room);
        FindWay(RoomSide.transform.position);
    }
    void FindWay(Vector3 Root)
    {
        Vector3 up = new Vector3((int)Root.x, (int)Root.y + 1, 0);
        Vector3 down = new Vector3((int)Root.x, (int)Root.y - 1, 0);
        Vector3 left = new Vector3((int)Root.x - 1, (int)Root.y, 0);
        Vector3 right = new Vector3((int)Root.x + 1, (int)Root.y, 0);
        CubeType UpCube, DownCube, LeftCube, RightCube;
        if (up.y <= y)
        {
            map.TryGetValue(up, out UpCube);
            if (UpCube.SType == 2&&!link.ContainsKey(up))
            {
                link.Add(up, UpCube.Cube);
                FindWay(up);
            }
        }
        if (down.y >= 1)
        {
            map.TryGetValue(down, out DownCube);
            if (DownCube.SType == 2 && !link.ContainsKey(down))
            {
                link.Add(down, DownCube.Cube);
                FindWay(down);
            }
        }
        if (left.x >= 1)
        {
            map.TryGetValue(left, out LeftCube);
            if (LeftCube.SType == 2 && !link.ContainsKey(left))
            {                link.Add(left, LeftCube.Cube);
                FindWay(left);
            }
        }
        if (right.x <= x)
        {
            map.TryGetValue(right, out RightCube);
            if (RightCube.SType == 2 && !link.ContainsKey(right))
            {
                link.Add(right, RightCube.Cube);
                FindWay(right);
            }
        }
    }
    void  RoomGrow()
    {
        GameObject Room = GameObject.Find("room").gameObject;
        bool judge = true;
        bool RoomJudge = true;
        Vector3 fc = default;

        foreach(KeyValuePair<Vector3,GameObject> kvp in link)
        {
            judge = true;
            RoomJudge = true;
            fc = kvp.Key;
            Vector3 up = new Vector3((int)fc.x, (int)fc.y + 1, 0);
            Vector3 down = new Vector3((int)fc.x, (int)fc.y - 1, 0);
            Vector3 left = new Vector3((int)fc.x - 1, (int)fc.y, 0);
            Vector3 right = new Vector3((int)fc.x + 1, (int)fc.y, 0);
            CubeType RUpCube, RDownCube, RLeftCube, RRightCube;
            if (up.y <= y)
            {
                map.TryGetValue(up, out RUpCube);
                if (RUpCube.Type == 3&&RUpCube.Cube.transform.parent.gameObject.transform.parent.gameObject == Room)
                {
                    GameObject Roomx = RUpCube.Cube.transform.parent.gameObject;
                    foreach(GameObject lc in RoomLink)
                    {
                        if (lc.Equals(Roomx))
                        {
                            RoomJudge = false;
                            break;
                        }
                        
                    }
                    if(RoomJudge)
                    {
                        RUpCube.ChangeType(2);
                        RUpCube.Cube = Instantiate(RUpCube.PrefabCube, RUpCube.Position, default, Roomx.transform);
                        RUpCube.SType = 7;
                        LinkRoom(Roomx);
                        judge = false;
                        break;
                    }
                }
            }
            if (down.y >= 0)
            {
                map.TryGetValue(down, out RDownCube);
                if (RDownCube.Type == 3 && RDownCube.Cube.transform.parent.gameObject.transform.parent.gameObject == Room)
                {
                    GameObject Roomx = RDownCube.Cube.transform.parent.gameObject;
                    foreach (GameObject lc in RoomLink)
                    {
                        if (lc.Equals(Roomx))
                        {
                            RoomJudge = false;
                            break;
                        }

                    }
                    if (RoomJudge)
                    {
                        RDownCube.ChangeType(2);
                        RDownCube.Cube = Instantiate(RDownCube.PrefabCube, RDownCube.Position, default, Roomx.transform);
                        RDownCube.SType = 7;
                        LinkRoom(Roomx);
                        judge = false;
                        break;
                    }
                }
            }
            if (left.x >= 1)
            {
                map.TryGetValue(left, out RLeftCube);
                if (RLeftCube.Type == 3 && RLeftCube.Cube.transform.parent.gameObject.transform.parent.gameObject == Room)
                {
                    GameObject Roomx = RLeftCube.Cube.transform.parent.gameObject;
                    foreach (GameObject lc in RoomLink)
                    {
                        if (lc.Equals(Roomx))
                        {
                            RoomJudge = false;
                            break;
                        }

                    }
                    if (RoomJudge)
                    {
                        RLeftCube.ChangeType(2);
                        RLeftCube.Cube = Instantiate(RLeftCube.PrefabCube, RLeftCube.Position, default, Roomx.transform);
                        RLeftCube.SType = 7;
                        LinkRoom(Roomx);
                        judge = false;
                        break;
                    }
                }
            }
            if (right.x <= x)
            {
                map.TryGetValue(right, out RRightCube);
                if (RRightCube.Type == 3 && RRightCube.Cube.transform.parent.gameObject.transform.parent.gameObject == Room)
                {
                    Debug.Log("work");
                    GameObject Roomx = RRightCube.Cube.transform.parent.gameObject;
                    foreach (GameObject lc in RoomLink)
                    {
                        Debug.Log(lc);
                        if (lc.Equals(Roomx))
                        {
                            RoomJudge = false;
                            break;
                        }
                    }
                    Debug.Log(RoomJudge);
                    if (RoomJudge)
                    {
                        RRightCube.ChangeType(2);
                        RRightCube.Cube = Instantiate(RRightCube.PrefabCube, RRightCube.Position, default, Roomx.transform);
                        RRightCube.SType = 7;
                        LinkRoom(Roomx);
                        judge = false;
                        break;
                    }
                }
            }
        }
        if(!judge)
        {
            RoomGrow();
        }
    }
    void ClearAsile(Vector3 Root,int n)
    {
        if (n <= DeleteAisle)
        {
            GameObject stone = GameObject.Find("stone").gameObject;
            GameObject asile = GameObject.Find("aisle").gameObject;
            CubeType now;
            map.TryGetValue(Root, out now);
            Vector3 up = new Vector3((int)Root.x, (int)Root.y + 1, 0);
            Vector3 down = new Vector3((int)Root.x, (int)Root.y - 1, 0);
            Vector3 left = new Vector3((int)Root.x - 1, (int)Root.y, 0);
            Vector3 right = new Vector3((int)Root.x + 1, (int)Root.y, 0);
            CubeType AUpCube, ADownCube, ALeftCube, ARightCube;
            map.TryGetValue(up, out AUpCube);
            map.TryGetValue(down, out ADownCube);
            map.TryGetValue(left, out ALeftCube);
            map.TryGetValue(right, out ARightCube);
            if (AUpCube.Type == 3 && ADownCube.Type == 3 && ALeftCube.Type == 3 && ARightCube.Type == 3)
            {
                now.ChangeType(3);
                Destroy(now.Cube);
                now.Cube = Instantiate(now.PrefabCube, now.Position, default, stone.transform);
            }
            else if (AUpCube.Type != 3 && ADownCube.Type == 3 && ALeftCube.Type == 3 && ARightCube.Type == 3)
            {
                now.ChangeType(3);
                Destroy(now.Cube);
                now.Cube = Instantiate(now.PrefabCube, now.Position, default, stone.transform);
                ClearAsile(AUpCube.Cube.transform.position,n+1);
            }
            else if (ADownCube.Type != 3 && AUpCube.Type == 3 && ALeftCube.Type == 3 && ARightCube.Type == 3)
            {
                now.ChangeType(3);
                Destroy(now.Cube);
                now.Cube = Instantiate(now.PrefabCube, now.Position, default, stone.transform);
                ClearAsile(ADownCube.Cube.transform.position,n+1);
            }
            else if (ALeftCube.Type != 3 && ADownCube.Type == 3 && AUpCube.Type == 3 && ARightCube.Type == 3)
            {
                now.ChangeType(3);
                Destroy(now.Cube);
                now.Cube = Instantiate(now.PrefabCube, now.Position, default, stone.transform);
                ClearAsile(ALeftCube.Cube.transform.position,n+1);
            }
            else if (ARightCube.Type != 3 && ADownCube.Type == 3 && ALeftCube.Type == 3 && AUpCube.Type == 3)
            {
                now.ChangeType(3);
                Destroy(now.Cube);
                now.Cube = Instantiate(now.PrefabCube, now.Position, default, stone.transform);
                ClearAsile(ARightCube.Cube.transform.position,n+1);
            }
        }
    }
}
public class CubeType
{
    public GameObject PrefabCube { get; set; }
    public GameObject Cube { get; set; }
    public Vector3 Position { get; set; }
    public int Type { get; set; }
    public int SType { get; set; }
    public CubeType(Vector3 position, int type)
    {
        Position = position;
        Type = type;
        switch(Type)
        {
            case 1:
                {
                    PrefabCube = Resources.Load("room") as GameObject;
                    SType = 1;
                    break;
                }
            case 2:
                {
                    PrefabCube = Resources.Load("aisle") as GameObject;
                    SType = 2;
                    break;
                }
            case 3:
                {
                    PrefabCube = Resources.Load("side") as GameObject;
                    SType = 3;
                    break;
                }
            case 4:
                {
                    PrefabCube = Resources.Load("stone") as GameObject;
                    SType = 4;
                    break;
                }
        }
    }
    public void ChangeType(int num)
    {
        Type = num;
        switch (Type)
        {
            case 1:
                {
                    PrefabCube = Resources.Load("room") as GameObject;
                    SType = 1;
                    break;
                }
            case 2:
                {
                    PrefabCube = Resources.Load("aisle") as GameObject;
                    SType = 2;
                    break;
                }
            case 3:
                {
                    PrefabCube = Resources.Load("side") as GameObject;
                    SType = 3;
                    break;
                }
            case 4:
                {
                    PrefabCube = Resources.Load("stone") as GameObject;
                    SType = 4;
                    break;
                }
        }
    }
}
